import { useState } from 'react';
import {
  X, Sun, Moon, Check, Palette,
} from 'lucide-react';
import type { ThemeColor } from '@/types';
import { cn } from '@/lib/utils';

interface ThemeSettingsProps {
  isOpen: boolean;
  onClose: () => void;
  colorScheme: ThemeColor;
  onChangeColorScheme: (scheme: ThemeColor) => void;
  isDark: boolean;
  onToggleDark: () => void;
}

interface ThemeOption {
  id: ThemeColor;
  name: string;
  description: string;
  lightPreview: string[];
  darkPreview: string[];
  isGlass?: boolean;
}

const THEME_OPTIONS: ThemeOption[] = [
  {
    id: 'coral',
    name: '珊瑚橘',
    description: '温暖舒适，如初日阳光',
    lightPreview: ['#faf6f2', '#ffffff', '#d4857a'],
    darkPreview: ['#1a1f2e', '#1e2530', '#d4857a'],
  },
  {
    id: 'ocean',
    name: '海洋蓝',
    description: '清新沉稳，如深海静谧',
    lightPreview: ['#f0f5fa', '#ffffff', '#5b8def'],
    darkPreview: ['#111d35', '#162240', '#5b8def'],
  },
  {
    id: 'mint',
    name: '薄荷绿',
    description: '自然活力，如林间清风',
    lightPreview: ['#f0f7f3', '#ffffff', '#5dbe9d'],
    darkPreview: ['#0f2a1f', '#163528', '#5dbe9d'],
  },
  {
    id: 'lavender',
    name: '薰衣草',
    description: '优雅宁静，如花海梦境',
    lightPreview: ['#f5f2f8', '#ffffff', '#9b8ec7'],
    darkPreview: ['#1c1630', '#261f3e', '#b8a8e0'],
  },
  {
    id: 'amber',
    name: '琥珀金',
    description: '复古高级，如秋日暖阳',
    lightPreview: ['#fbf5ed', '#ffffff', '#c8956c'],
    darkPreview: ['#281f18', '#342a20', '#d4a878'],
  },
  {
    id: 'glass',
    name: '液态玻璃',
    description: 'Apple Liquid Glass · 折射·流动·透明',
    lightPreview: ['#dde3f0', 'rgba(255,255,255,0.45)', '#5b8def'],
    darkPreview: ['#080d18', 'rgba(255,255,255,0.06)', '#7ba8ff'],
    isGlass: true,
  },
];

export function ThemeSettings({
  isOpen, onClose, colorScheme, onChangeColorScheme, isDark, onToggleDark,
}: ThemeSettingsProps) {
  const [previewDark, setPreviewDark] = useState(false);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center bg-[var(--app-modal-overlay)] backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="bg-[var(--app-surface)] rounded-2xl shadow-2xl w-[460px] max-h-[85vh] flex flex-col border border-[var(--app-border)]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-[var(--app-border)]">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[var(--app-surface-hover)] flex items-center justify-center">
              <Palette size={18} className="text-[var(--app-accent)]" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-[var(--app-text)]">个性化主题</h3>
              <p className="text-[11px] text-[var(--app-text-muted)]">选择你喜欢的配色风格</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-[var(--app-text-muted)] hover:text-[var(--app-text)] hover:bg-[var(--app-surface-hover)] transition-all"
          >
            <X size={18} />
          </button>
        </div>

        {/* Dark/Light Toggle */}
        <div className="px-5 pt-4">
          <div className="flex items-center justify-between p-3 rounded-xl bg-[var(--app-surface-hover)] border border-[var(--app-border)]">
            <div className="flex items-center gap-2.5">
              {isDark ? <Moon size={16} className="text-[var(--app-accent)]" /> : <Sun size={16} className="text-[#d4857a]" />}
              <span className="text-sm font-medium text-[var(--app-text)]">
                {isDark ? '暗夜模式' : '日间模式'}
              </span>
            </div>
            <button
              onClick={onToggleDark}
              className={cn(
                'w-11 h-6 rounded-full transition-all relative',
                isDark ? 'bg-[var(--app-accent)]' : 'bg-[var(--app-border)]'
              )}
            >
              <span className={cn(
                'absolute top-[3px] w-[18px] h-[18px] rounded-full bg-white shadow-sm transition-all',
                isDark ? 'left-[22px]' : 'left-[3px]'
              )} />
            </button>
          </div>
        </div>

        {/* Preview mode toggle */}
        <div className="px-5 pt-3 flex items-center justify-end gap-2">
          <span className="text-[11px] text-[var(--app-text-muted)]">预览</span>
          <button
            onClick={() => setPreviewDark(false)}
            className={cn(
              'px-2.5 py-1 rounded-md text-[10px] font-medium transition-all',
              !previewDark ? 'bg-[var(--app-accent)] text-white' : 'text-[var(--app-text-muted)] hover:bg-[var(--app-surface-hover)]'
            )}
          >
            <Sun size={10} className="inline mr-1" />
            日间
          </button>
          <button
            onClick={() => setPreviewDark(true)}
            className={cn(
              'px-2.5 py-1 rounded-md text-[10px] font-medium transition-all',
              previewDark ? 'bg-[var(--app-accent)] text-white' : 'text-[var(--app-text-muted)] hover:bg-[var(--app-surface-hover)]'
            )}
          >
            <Moon size={10} className="inline mr-1" />
            暗夜
          </button>
        </div>

        {/* Theme Grid */}
        <div className="flex-1 overflow-y-auto px-5 pb-5 pt-2">
          <div className="grid grid-cols-2 gap-3">
            {THEME_OPTIONS.map((theme) => {
              const isActive = colorScheme === theme.id;
              const previews = previewDark ? theme.darkPreview : theme.lightPreview;

              return (
                <button
                  key={theme.id}
                  onClick={() => onChangeColorScheme(theme.id)}
                  className={cn(
                    'relative flex flex-col items-start p-3.5 rounded-xl border-2 transition-all duration-200 text-left group',
                    isActive
                      ? 'border-[var(--app-accent)] shadow-md'
                      : 'border-[var(--app-border)] hover:border-[var(--app-border-hover)]/50 hover:shadow-sm'
                  )}
                >
                  {/* Active checkmark */}
                  {isActive && (
                    <div className="absolute -top-2 -right-2 w-5 h-5 rounded-full bg-[var(--app-accent)] flex items-center justify-center shadow-sm z-10">
                      <Check size={12} className="text-white" />
                    </div>
                  )}

                  {/* Preview bar — 3 color strips */}
                  <div className="w-full flex gap-1.5 mb-3">
                    {previews.map((color, i) => (
                      <div
                        key={i}
                        className={cn(
                          'h-10 rounded-lg flex-1 shadow-sm',
                          theme.isGlass && 'backdrop-blur-md border border-white/20'
                        )}
                        style={{
                          background: color,
                          border: theme.isGlass
                            ? '1px solid rgba(255,255,255,0.25)'
                            : i === 1 && !previewDark ? '1px solid rgba(0,0,0,0.06)' : 'none',
                          boxShadow: theme.isGlass
                            ? 'inset 0 1px 0 rgba(255,255,255,0.4), 0 4px 12px rgba(60,80,130,0.12)'
                            : undefined,
                        }}
                      />
                    ))}
                  </div>

                  {/* Name & Description */}
                  <span className={cn(
                    'text-sm font-semibold',
                    isActive ? 'text-[var(--app-accent)]' : 'text-[var(--app-text)]'
                  )}>
                    {theme.name}
                  </span>
                  <span className="text-[11px] text-[var(--app-text-muted)] mt-0.5 leading-relaxed">
                    {theme.description}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
