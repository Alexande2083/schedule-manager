import { X, Play, Pause, RotateCcw } from 'lucide-react';

interface PomodoroModalProps {
  isOpen: boolean;
  onClose: () => void;
  minutes: number;
  seconds: number;
  isRunning: boolean;
  completedToday: number;
  progress: number;
  onStart: () => void;
  onPause: () => void;
  onReset: () => void;
}

export function PomodoroModal({
  isOpen,
  onClose,
  minutes,
  seconds,
  isRunning,
  completedToday,
  progress,
  onStart,
  onPause,
  onReset,
}: PomodoroModalProps) {
  if (!isOpen) return null;

  const radius = 80;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (progress / 100) * circumference;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[var(--app-modal-overlay)] backdrop-blur-sm">
      <div className="bg-[var(--app-surface)] rounded-2xl shadow-2xl p-8 w-[360px] relative border border-[var(--app-border)]">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-[var(--app-text-muted)] hover:text-[var(--app-text)] hover:bg-[var(--app-surface-hover)] transition-all"
        >
          <X size={18} />
        </button>

        <h3 className="text-lg font-semibold text-[var(--app-text)] text-center mb-6">
          番茄钟
        </h3>

        <div className="relative w-[180px] h-[180px] mx-auto mb-6">
          <svg className="w-full h-full -rotate-90" viewBox="0 0 180 180">
            <circle
              cx="90"
              cy="90"
              r={radius}
              fill="none"
              stroke="var(--app-pomodoro-ring)"
              strokeWidth="8"
            />
            <circle
              cx="90"
              cy="90"
              r={radius}
              fill="none"
              stroke="#d4857a"
              strokeWidth="8"
              strokeLinecap="round"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              className="transition-all duration-1000 ease-linear"
            />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-3xl font-bold text-[var(--app-text)] font-mono">
              {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
            </span>
            <span className="text-xs text-[var(--app-text-muted)] mt-1">
              {isRunning ? '专注中...' : '准备开始'}
            </span>
          </div>
        </div>

        <div className="flex items-center justify-center gap-3 mb-4">
          {isRunning ? (
            <button
              onClick={onPause}
              className="flex items-center gap-2 px-5 py-2.5 bg-[#d4857a] text-white rounded-xl text-sm font-medium hover:bg-[#c97a6e] transition-colors"
            >
              <Pause size={16} />
              暂停
            </button>
          ) : (
            <button
              onClick={onStart}
              className="flex items-center gap-2 px-5 py-2.5 bg-[#d4857a] text-white rounded-xl text-sm font-medium hover:bg-[#c97a6e] transition-colors"
            >
              <Play size={16} />
              {progress > 0 ? '继续' : '开始'}
            </button>
          )}
          <button
            onClick={onReset}
            className="flex items-center gap-2 px-5 py-2.5 bg-[var(--app-surface-hover)] text-[var(--app-text-secondary)] rounded-xl text-sm font-medium hover:bg-[var(--app-border)] transition-colors"
          >
            <RotateCcw size={16} />
            重置
          </button>
        </div>

        <div className="text-center">
          <span className="text-xs text-[var(--app-text-muted)]">
            今日完成: <span className="text-[#d4857a] font-semibold">{completedToday}</span> 个番茄
          </span>
        </div>
      </div>
    </div>
  );
}
