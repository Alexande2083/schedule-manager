import { useState, useEffect, useRef, useCallback } from 'react';
import { useLocalStorage } from './useLocalStorage';
import { getToday } from '@/utils/date';

interface PomodoroTimer {
  minutes: number;
  seconds: number;
  isRunning: boolean;
  completedToday: number;
  lastDate: string;
}

export function usePomodoro() {
  const [timer, setTimer] = useLocalStorage<PomodoroTimer>('sunsama-pomodoro', {
    minutes: 25,
    seconds: 0,
    isRunning: false,
    completedToday: 0,
    lastDate: getToday(),
  });

  const [isRunning, setIsRunning] = useState(timer.isRunning);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Reset daily count
  useEffect(() => {
    const today = getToday();
    if (timer.lastDate !== today) {
      setTimer(prev => ({ ...prev, completedToday: 0, lastDate: today }));
    }
  }, []);

  useEffect(() => {
    if (isRunning) {
      intervalRef.current = setInterval(() => {
        setTimer(prev => {
          if (prev.minutes === 0 && prev.seconds === 0) {
            return {
              ...prev,
              isRunning: false,
              completedToday: prev.completedToday + 1,
            };
          }
          if (prev.seconds === 0) {
            return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
          }
          return { ...prev, seconds: prev.seconds - 1 };
        });
      }, 1000);
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isRunning]);

  useEffect(() => {
    setTimer(prev => ({ ...prev, isRunning }));
  }, [isRunning]);

  const start = useCallback(() => setIsRunning(true), []);
  const pause = useCallback(() => setIsRunning(false), []);
  const reset = useCallback(() => {
    setIsRunning(false);
    setTimer(prev => ({ ...prev, minutes: 25, seconds: 0, isRunning: false }));
  }, []);

  const progress = ((25 - timer.minutes - timer.seconds / 60) / 25) * 100;

  return {
    minutes: timer.minutes,
    seconds: timer.seconds,
    isRunning,
    completedToday: timer.completedToday,
    start,
    pause,
    reset,
    progress,
  };
}
